# Judul Dokumen
---

Dokumen perangkat lunak yang bagus

## Introduction

Software ini digunakan untuk meringankan beban manusia

### Fitur Utama

* Mendaftarkan pasien pada rumah sakit
* Membayar biaya perawatan
* **Booking kamar rumah sakit**
* ~~Membeli obat~~

### System Requirement

| Komponen | Versi |
| -------- | ----- |
|   PHP    |  7.1  |
|  NodeJS  |  12.0 |
|  MariaDB |  8.0  |

> Versi PHP boleh lebih tinggi